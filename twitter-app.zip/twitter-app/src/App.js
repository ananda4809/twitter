import React from 'react';
import './App.css';


import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";


import Twitter from "./components/twitter";
import Login from "./components/login";

function App() {
  return (
    <Router>
      <div>
      <Switch>
        <Route path="/login">
          <Login />
        </Route>
        <Route path="/twitter">
          <Twitter />
        </Route>
      </Switch>
      </div>
    </Router>
  )
}

export default App;
